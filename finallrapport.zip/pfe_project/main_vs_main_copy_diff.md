# Comparison: `main.tex` vs `main_copy.tex`

This report summarizes the differences between `main.tex` (source) and `main_copy.tex` (target), based on a `git diff --no-index` comparison.

## Notes

- **Line endings**: Git warns that both files are currently LF and will be converted to CRLF in the working copy on next Git touch. This does **not** change content meaning, but it can make diffs noisier on Windows.

## High-level summary

- **Front matter is heavily reworked in `main_copy.tex`**: the title page is completely redesigned and **new dedication content is added**.
- **Text/typography cleanup** appears throughout: replacing awkward spacing with `---`, normalizing keyword separators, and simplifying bold/mbox formatting.
- **Document structure changed**: the **chapter roadmap** in the general introduction is rewritten and expanded (new chapter/release breakdown).
- **Large content removal**: a substantial section near the end of `main.tex` (observability/admin portal showcase + deployment section + conclusion) is **removed** in `main_copy.tex`.
- **Bibliography trimmed/changed**: many references are removed; a **new `nextstep_website`** bibitem is added and cited from the company presentation section.

## Detailed differences (by area)

### 1) Title page redesign (major)

`main_copy.tex` replaces the old title-page block with a new layout:

- **Old**: title page embedded after a commented separator and used a background image (`images/bg.png`) with opacity.
- **New**: title page is rebuilt with:
  - **Dashed border retained**, but watermarking changes to **spiral arc motifs** (left and right) drawn via `\foreach`.
  - A new centered header containing university metadata, approval placeholders, and a new logo file reference **`images/logo_horizon.pdf`**.
  - A new title composition (End Of Studies Project Report), major details, authors, and jury table using `tabularx`.
  - A formatted “Academic Year: 2025 / 2026” footer.

Net effect: **the entire visual identity of the title page differs** (layout, assets, and drawn elements).

### 2) New dedication section content (added)

Immediately after the title page, `main_copy.tex` adds a dedicated chapter:

- `\chapter*{Dedication}` plus TOC entry (`\addcontentsline{toc}{chapter}{Dedication}`)
- A full dedication text block addressed to parents, brother, sister, professors, friends, and a signature line.

In contrast, `main.tex` used that space primarily for the title-page content and does not contain this same dedication block there.

### 3) Abstract / Résumé punctuation and keyword formatting (small but systematic)

Examples of changes:

- Inserted em-dash style separators using `---` instead of loose spacing (e.g., “interact --- ensuring …”).
- Normalized “Prometheus/Grafana” formatting by removing `\mbox{}` wrappers.
- Fixed keyword separators where items were previously separated by double spaces; now consistently `---` separated.

### 4) Acronyms table: formatting refactor (same content, different layout)

The acronyms longtable is reformatted:

- **Old**: each acronym label on one line, description on the next line (more vertical whitespace).
- **New**: each acronym is kept on a single row line, aligned with consistent spacing.

This is mostly a **presentation change** (content looks equivalent in the shown diff portion).

### 5) “General introduction” chapter roadmap rewritten (structural change)

The overview of the report’s structure is rewritten:

- **Old**: described Chapters 1–3 in broader terms.
- **New**: expands and changes the outline into **Chapters 1–5**, with explicit mention of:
  - host company + methodology in Chapter 1
  - requirements formalization in Chapter 2
  - architecture/CI-CD in Chapter 3
  - Release 1 in Chapter 4
  - Release 2 in Chapter 5

Net effect: `main_copy.tex` presents a **more granular / release-oriented structure**.

### 6) Chapter 1 intro adjusted + new citation

In `main_copy.tex`:

- The Chapter 1 introduction text is rewritten (shorter, explicitly lists what the chapter contains).
- The “ISO-9001 / ISO-27001” line adds a citation: `\cite{nextstep_website}`.

Bibliography adds:

- `\bibitem{nextstep_website}` pointing to Next Step IT’s official site.

### 7) Major removal near the end: Observability/Admin portal + Deployment + conclusion

In the later part of `main.tex`, a large block is present that includes (among others):

- Observability architecture figure and explanation
- Admin portal interaction description and showcase figures (Grafana dashboards, security panels, etc.)
- A full **Deployment** section (containerization strategy table, infra architecture, Cloudflare Tunnels, deployment workflow figures)
- A chapter conclusion describing observability and deployment decisions

This entire block appears as **deleted** (lines prefixed with `-`) with no corresponding replacement, meaning:

- **`main_copy.tex` does not contain these sections** (at least not in the same location/content).

### 8) Bibliography: many entries removed

Near the bibliography, `main.tex` contains many bibitems (Kubernetes, Vault, ModSecurity CRS, Prometheus, Grafana, Loki, FastAPI, Vite, Redis, OAuth RFCs, Docker, DistilBERT, etc.).

In `main_copy.tex`, these shown entries are removed, leaving (in the diff excerpt) only the new:

- `\bibitem{nextstep_website}` (and presumably other bibitems earlier in the list that weren’t part of the diff excerpt).

## What this means (practical)

- If `main_copy.tex` is intended as a “cleaned-up” version of `main.tex`, it currently contains **significant additions** (title page + dedication) **and also significant omissions** (deployment/observability content and many bibliography entries).
- If the removals were accidental, the quickest way to confirm is to search within `main_copy.tex` for `\section{Deployment}` or unique phrases from the removed block (e.g., “Cloudflare Tunnels”, “Grafana dashboard”, “observability pipeline”).

