"""Convert all raster images under pfe_project/images to single-page PDFs."""
from __future__ import annotations

import sys
from pathlib import Path

from PIL import Image

PROJECT_ROOT = Path(__file__).resolve().parents[1]
IMAGES_ROOT = PROJECT_ROOT / "images"
RASTER_SUFFIXES = {".png", ".jpg", ".jpeg", ".gif", ".bmp", ".webp", ".tif", ".tiff"}


def image_to_pdf(src: Path, dest: Path) -> None:
    with Image.open(src) as im:
        if im.mode in ("RGBA", "LA", "P"):
            background = Image.new("RGB", im.size, (255, 255, 255))
            alpha = im.convert("RGBA")
            background.paste(alpha, mask=alpha.split()[-1])
            im = background
        elif im.mode != "RGB":
            im = im.convert("RGB")
        dest.parent.mkdir(parents=True, exist_ok=True)
        im.save(dest, "PDF", resolution=300.0)


def main() -> int:
    if not IMAGES_ROOT.is_dir():
        print(f"Missing images folder: {IMAGES_ROOT}", file=sys.stderr)
        return 1

    sources = sorted(
        p for p in IMAGES_ROOT.rglob("*") if p.is_file() and p.suffix.lower() in RASTER_SUFFIXES
    )
    ok, failed = 0, []

    for src in sources:
        dest = src.with_suffix(".pdf")
        try:
            image_to_pdf(src, dest)
            print(f"OK  {src.relative_to(PROJECT_ROOT)} -> {dest.name}")
            ok += 1
        except Exception as exc:
            print(f"FAIL {src}: {exc}", file=sys.stderr)
            failed.append(str(src))

    print(f"\nConverted {ok}/{len(sources)} images to PDF under {IMAGES_ROOT}")
    if failed:
        print(f"Failed ({len(failed)}):", *failed, sep="\n  ")
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
