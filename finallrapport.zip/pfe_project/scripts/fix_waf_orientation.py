"""Redraw WAF box with same layout as Clients/Kong (icon left, vertical text)."""
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parents[1]
PNG = ROOT / "images" / "centrelized.png"
PDF = ROOT / "images" / "centrelized.pdf"

# Other boxes use 141–305; WAF is slightly wider for readability
WAF_LEFT = 128
WAF_RIGHT = 318
BOX_W = WAF_RIGHT - WAF_LEFT
WAF_TOP = 267
WAF_BOTTOM = 357
BOX_H = WAF_BOTTOM - WAF_TOP
CX = (141 + 305) // 2  # main flow arrows stay centered with other boxes

FILL = (255, 247, 237)
OUTLINE = (234, 88, 12)


def load_font(size: int, bold: bool = False) -> ImageFont.FreeTypeFont | ImageFont.ImageFont:
    paths = (
        ["C:/Windows/Fonts/segoeuib.ttf", "C:/Windows/Fonts/arialbd.ttf"]
        if bold
        else ["C:/Windows/Fonts/segoeui.ttf", "C:/Windows/Fonts/arial.ttf"]
    )
    for path in paths:
        if Path(path).is_file():
            return ImageFont.truetype(path, size)
    return ImageFont.load_default()


def horizontal_to_vertical(
    text: str,
    font: ImageFont.ImageFont,
    fill: tuple[int, int, int],
) -> Image.Image:
    """Match diagram style: horizontal string -> 90° CW (reads top-to-bottom)."""
    pad = Image.new("RGBA", (1, 1))
    draw = ImageDraw.Draw(pad)
    bbox = draw.textbbox((0, 0), text, font=font)
    tw, th = bbox[2] - bbox[0], bbox[3] - bbox[1]
    layer = Image.new("RGBA", (tw + 4, th + 4), (0, 0, 0, 0))
    ImageDraw.Draw(layer).text((2, 2), text, font=font, fill=fill + (255,))
    return layer.transpose(Image.Transpose.ROTATE_270)


def build_shield_icon(size: int = 28) -> Image.Image:
    """Draw shield on a small layer, rotate 90° CW to match other box icons."""
    pad = size * 2 + 10
    icon = Image.new("RGBA", (pad, pad), (0, 0, 0, 0))
    draw = ImageDraw.Draw(icon)
    cx, cy = pad // 2, pad // 2
    s = size
    top = cy - s
    pts = [
        (cx, top),
        (cx + s, top + s // 2),
        (cx + s - 4, cy + s // 2),
        (cx, cy + s),
        (cx - s + 4, cy + s // 2),
        (cx - s, top + s // 2),
    ]
    draw.polygon(pts, fill=(234, 88, 12), outline=(194, 65, 12))
    draw.line([(cx, top + 8), (cx, cy + s - 6)], fill=(255, 255, 255), width=2)
    return icon.transpose(Image.Transpose.ROTATE_270)


def build_waf_content() -> Image.Image:
    layer = Image.new("RGBA", (BOX_W, BOX_H), FILL + (255,))
    draw = ImageDraw.Draw(layer)
    draw.rounded_rectangle((1, 1, BOX_W - 2, BOX_H - 2), radius=12, outline=OUTLINE, width=2)

    title_font = load_font(10, bold=True)
    body_font = load_font(8)
    small_font = load_font(7)

    # Left: icon only — rotated like Clients / Kong logos (not the whole box)
    shield = build_shield_icon(22)
    layer.paste(
        shield,
        (30 - shield.width // 2, BOX_H // 2 - shield.height // 2),
        shield,
    )

    # Right: vertical text (90° CW, top-to-bottom like other boxes)
    x_title = 98
    title = horizontal_to_vertical(
        "Web Application Firewall (WAF)", title_font, (124, 45, 18)
    )
    layer.paste(title, (x_title, 6), title)

    sub = horizontal_to_vertical("(ModSecurity / OWASP CRS)", small_font, (154, 52, 18))
    layer.paste(sub, (x_title + 14, 10), sub)

    bullets = [
        "Request Inspection",
        "SQLi / XSS Blocking",
        "IP & Rule Filtering",
    ]
    bx = 126
    by = 8
    for line in bullets:
        bimg = horizontal_to_vertical(f"  {line}", body_font, (30, 41, 59))
        layer.paste(bimg, (bx, by), bimg)
        by += bimg.size[1] + 4

    return layer


def draw_arrow_segment(draw: ImageDraw.ImageDraw, y0: int, y1: int) -> None:
    draw.line([(CX, y0), (CX, y1 - 10)], fill=(0, 0, 0), width=2)
    draw.polygon([(CX, y1), (CX - 7, y1 - 12), (CX + 7, y1 - 12)], fill=(0, 0, 0))


def main() -> None:
    img = Image.open(PNG).convert("RGBA")
    draw = ImageDraw.Draw(img)

    clear_top = WAF_TOP - 6
    clear_bottom = WAF_BOTTOM + 6
    draw.rectangle((WAF_LEFT - 2, clear_top, WAF_RIGHT + 2, clear_bottom), fill=(255, 255, 255, 255))

    draw_arrow_segment(draw, 243, WAF_TOP - 2)
    draw_arrow_segment(draw, WAF_BOTTOM + 2, 453)

    content = build_waf_content()
    img.paste(content, (WAF_LEFT, WAF_TOP), content)

    final = img.convert("RGB")
    final.save(PNG, "PNG", optimize=True)
    final.save(PDF, "PDF", resolution=300.0)
    print(f"Updated WAF box in {PNG}")


if __name__ == "__main__":
    main()
