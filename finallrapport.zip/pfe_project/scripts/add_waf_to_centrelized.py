"""Insert WAF layer between Clients and Kong in centrelized.png."""
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parents[1]
PNG = ROOT / "images" / "centrelized.png"
PDF = ROOT / "images" / "centrelized.pdf"

# Layout (from image analysis)
CLIENTS_BOTTOM = 239
KONG_TOP = 299
BOX_LEFT = 141
BOX_RIGHT = 305
BOX_WIDTH = BOX_RIGHT - BOX_LEFT
CX = (BOX_LEFT + BOX_RIGHT) // 2

INSERT_H = 148  # WAF box + two arrow segments
WAF_TOP = CLIENTS_BOTTOM + 28
WAF_BOTTOM = WAF_TOP + 92
SPLIT_Y = KONG_TOP  # shift everything from Kong downward


def load_font(size: int, bold: bool = False) -> ImageFont.FreeTypeFont | ImageFont.ImageFont:
    candidates = []
    if bold:
        candidates += [
            "C:/Windows/Fonts/segoeuib.ttf",
            "C:/Windows/Fonts/arialbd.ttf",
        ]
    else:
        candidates += [
            "C:/Windows/Fonts/segoeui.ttf",
            "C:/Windows/Fonts/arial.ttf",
        ]
    for path in candidates:
        if Path(path).is_file():
            return ImageFont.truetype(path, size)
    return ImageFont.load_default()


def draw_arrow(draw: ImageDraw.ImageDraw, y0: int, y1: int) -> None:
    draw.line([(CX, y0), (CX, y1 - 10)], fill=(0, 0, 0), width=2)
    draw.polygon([(CX, y1), (CX - 7, y1 - 12), (CX + 7, y1 - 12)], fill=(0, 0, 0))


def draw_rounded_box(
    draw: ImageDraw.ImageDraw,
    xy: tuple[int, int, int, int],
    fill: tuple[int, int, int],
    outline: tuple[int, int, int],
    radius: int = 14,
    width: int = 2,
) -> None:
    draw.rounded_rectangle(xy, radius=radius, fill=fill, outline=outline, width=width)


def draw_shield(draw: ImageDraw.ImageDraw, cx: int, cy: int, size: int) -> None:
    s = size // 2
    top = cy - s
    pts = [
        (cx, top),
        (cx + s, top + s // 2),
        (cx + s - 4, cy + s // 2),
        (cx, cy + s),
        (cx - s + 4, cy + s // 2),
        (cx - s, top + s // 2),
    ]
    draw.polygon(pts, fill=(234, 88, 12), outline=(194, 65, 12))
    draw.line([(cx, top + 8), (cx, cy + s - 6)], fill=(255, 255, 255), width=2)
    draw.arc([cx - 6, cy - 4, cx + 6, cy + 8], start=200, end=340, fill=(255, 255, 255), width=2)


def draw_waf_layer(draw: ImageDraw.ImageDraw) -> None:
    fill = (255, 247, 237)  # orange-50
    outline = (234, 88, 12)  # orange-600
    draw_rounded_box(draw, (BOX_LEFT, WAF_TOP, BOX_RIGHT, WAF_BOTTOM), fill, outline)

    title_font = load_font(11, bold=True)
    body_font = load_font(9)
    small_font = load_font(8)

    draw_shield(draw, BOX_LEFT + 28, (WAF_TOP + WAF_BOTTOM) // 2 - 4, 34)

    tx = BOX_LEFT + 52
    draw.text((tx, WAF_TOP + 14), "Web Application Firewall", fill=(124, 45, 18), font=title_font)
    draw.text((tx, WAF_TOP + 30), "(ModSecurity / OWASP CRS)", fill=(154, 52, 18), font=small_font)

    bullets = [
        "Request Inspection",
        "SQLi / XSS Blocking",
        "IP & Rule Filtering",
    ]
    y = WAF_TOP + 48
    for line in bullets:
        draw.text((tx + 4, y), f"• {line}", fill=(30, 41, 59), font=body_font)
        y += 13


def main() -> None:
    src = Image.open(PNG).convert("RGBA")
    w, h = src.size
    new_h = h + INSERT_H
    out = Image.new("RGBA", (w, new_h), (255, 255, 255, 255))

    # Top: through end of Clients box
    out.paste(src.crop((0, 0, w, SPLIT_Y)), (0, 0))

    # Bottom: Kong + rest shifted down
    bottom = src.crop((0, SPLIT_Y, w, h))
    out.paste(bottom, (0, SPLIT_Y + INSERT_H))

    draw = ImageDraw.Draw(out)

    # Arrows: Clients -> WAF -> Kong
    draw_arrow(draw, CLIENTS_BOTTOM + 4, WAF_TOP - 2)
    draw_arrow(draw, WAF_BOTTOM + 2, SPLIT_Y + INSERT_H - 6)

    draw_waf_layer(draw)

    final = out.convert("RGB")
    final.save(PNG, "PNG", optimize=True)
    final.save(PDF, "PDF", resolution=300.0)
    print(f"Updated {PNG}")
    print(f"Updated {PDF}")
    print(f"Canvas: {w}x{h} -> {w}x{new_h}")


if __name__ == "__main__":
    main()
